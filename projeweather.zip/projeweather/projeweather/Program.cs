﻿using System;
using System.Net.Http;
using Newtonsoft.Json;

class Program
{
    static void Main()
    {
        HavaDurumunuAl("istanbul");
        HavaDurumunuAl("izmir");
        HavaDurumunuAl("ankara");

        Console.ReadLine();
    }

    static async void HavaDurumunuAl(string sehir)
    {
        using (HttpClient istemci = new HttpClient())
        {
            try
            {
                string apiUrl = $"https://goweather.herokuapp.com/weather/{sehir}";
                string json = await istemci.GetStringAsync(apiUrl);

                HavaDurumuBilgisi havaDurumuBilgisi = JsonConvert.DeserializeObject<HavaDurumuBilgisi>(json);

                Console.WriteLine($"{sehir.ToUpper()} Hava Durumu:");

                Console.WriteLine($"Şu anki sıcaklık: {havaDurumuBilgisi.Sicaklik}");
                Console.WriteLine("Sonraki 3 gün için tahmini hava durumu:");

                foreach (var tahmin in havaDurumuBilgisi.Tahminler)
                {
                    Console.WriteLine($"Tarih: {tahmin.Tarih}, Sıcaklık: {tahmin.Sicaklik}");
                }

                Console.WriteLine();
            }
            catch (Exception hata)
            {
                Console.WriteLine($"{sehir} için hava durumu verisi alınırken bir hata oluştu: {hata.Message}");
            }
        }
    }
}

public class HavaDurumuBilgisi
{
    [JsonProperty("temperature")]
    public string Sicaklik { get; set; }

    [JsonProperty("forecast")]
    public Tahmin[] Tahminler { get; set; }
}

public class Tahmin
{
    [JsonProperty("date")]
    public string Tarih { get; set; }

    [JsonProperty("temperature")]
    public string Sicaklik { get; set; }
}
